<!-- Start Content-->
<div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                </div>
                <h4 class="page-title">Dashboard</h4>
            </div>
        </div>
    </div>
    <!-- end page title -->

        <div class="row">
        <div class="col-md-12">
            <div class="card card-body">
    <h1 class="card-title text-center">Vision  </h1>
    <p class="card-text">"To make a company that provides added value to all stakeholders"</p>
    <p> Always ready to be a trusted partner in every effort
        As a construction service company and development of ICT-based infrastructure device provision,
        ready to work together to support the needs required and be part of your company's progress :
    <li>ICT field</li>
    <li>Construction Services Sector</li>
    <li>Technology and Information Consultant</li>
    </p>
    </div> <!-- end card-->
    </div>

    <div class="col-md-12">
    <div class="card card-body">
    <h1 class="card-title text-center">Mission  </h1>
    <p class="card-text">"Providing welfare for the entire extended family of the Company"
    <p class="card-text">"Developing a trustworthy professional attitude"
    <ol>
    <p class="card-text">Committed to helping you build a network system that you need not only now, but for years to come. and at this time fiber optic cables are widely used in network and telecommunications installations along with the need for transmission media that have a large capacity
                         speed and bandwidth. Rodatama's competence in building fiber optic cable network system constructions includes : </p>    
                
                <li>Backbone & Backhaul</li>
                <li>Fiber To The Home (ftth)</li>
                <li>NOTE-B Last Mile</li>
                <li>Network Building</li>

                </ol>
                </p>
            </div> <!-- end card-->

       
<!-- container -->