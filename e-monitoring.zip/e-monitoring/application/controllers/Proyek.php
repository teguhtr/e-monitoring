<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Proyek extends CI_Controller {
	function __construct()
	{
		parent:: __construct();
		if(!$this->session->userdata('username')){
			redirect('login');
		}
		// $this->load->model('login_m');
	}
	public function index()
	{
		$this->load->view('daftar_proyek');
	}
}
public function tampilkan_proyek()
{
    // Fetch all records from the 'proyek' table
    $data['proyek'] = $this->db->get('proyek')->result_array();
    
    // Load the view and pass the data
    $this->load->view('daftar_proyek', $data);
}
}